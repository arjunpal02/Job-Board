export interface Job {
    id: string;
    url: string;
    title: string;
    by: string;
    time: number;
  }
  